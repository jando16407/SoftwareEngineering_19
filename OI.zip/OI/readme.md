# Office Inventory Software - OI

## Description

OI is web-based software designed to manage inventory for an office. This software utilizes individual employees to manage their own section in an office, and combines all inventories for management to oversee. Additionally, this inventory system also provides notifications for when an item is running low as well as when an employee reports faulty equipment.


## Instructions to run OI

* Please make sure you have an internet connection
* Please run the software using google chrome. (*other browsers are not recommended as some functionalities will not work)
* Windows and Macs are tested to work.
* There is no guarantee that it works on linux machines.